<?php

namespace App\Http\Controllers;

use App\Models\Location;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
        $this->middleware('role:admin')->except(['index']);
    }

    /**
     * Display a listing of locations (public)
     */
    public function index()
    {
        $locations = Location::all();
        return response()->json($locations);
    }

    /**
     * Store a newly created location
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|unique:locations',
            'region' => 'nullable|string'
        ]);

        $location = Location::create($request->all());
        
        return response()->json([
            'message' => 'Location created successfully',
            'location' => $location
        ], 201);
    }

    /**
     * Update the specified location
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'sometimes|string|unique:locations,name,' . $id,
            'region' => 'nullable|string'
        ]);

        $location = Location::findOrFail($id);
        $location->update($request->all());
        
        return response()->json([
            'message' => 'Location updated successfully',
            'location' => $location
        ]);
    }

    /**
     * Remove the specified location
     */
    public function destroy($id)
    {
        $location = Location::findOrFail($id);
        $location->delete();
        
        return response()->json([
            'message' => 'Location deleted successfully'
        ]);
    }
}