<?php

namespace App\Http\Controllers;

use App\Models\Message;                  // Fix: was lowercase 'message'
use Illuminate\Support\Facades\Auth;    // Fix: was lowercase 'support'
use Illuminate\Http\Request;

// Fix: removed $userId = Auth::id(); — can't have executable code outside a class

class MessageController extends Controller
{
    public function sendMessage(Request $request)   // Fix: removed trailing comma
    {
        $request->validate([
            'receiver_id' => 'required|exists:users,id',
            'message'     => 'required|string|max:1000',
        ]);

        $message = Message::create([
            'sender_id'   => Auth::id(),
            'receiver_id' => $request->receiver_id,
            'message'     => $request->message,
        ]);

        // Broadcast the message via WebSocket
        // event(new NewMessage($message));

        return response()->json([
            'message' => 'Message sent',
            'data'    => $message,
        ], 201);
    }

    public function getConversation($userId)
    {
        $messages = Message::where(function ($query) use ($userId) {
                $query->where('sender_id', Auth::id())
                      ->where('receiver_id', $userId);
            })
            ->orWhere(function ($query) use ($userId) {
                $query->where('sender_id', $userId)
                      ->where('receiver_id', Auth::id());
            })
            ->orderBy('created_at', 'asc')
            ->get();

        // Mark incoming messages as read
        Message::where('sender_id', $userId)
            ->where('receiver_id', Auth::id())
            ->update(['is_read' => true]);

        return response()->json($messages);
    }

    public function getConversations()
    {
        $userId = Auth::id();

        $conversations = Message::where('sender_id', $userId)
            ->orWhere('receiver_id', $userId)
            ->with(['sender', 'receiver'])
            ->orderBy('created_at', 'desc')
            ->get()
            ->unique(function ($message) use ($userId) {
                // Fix: closure didn't have access to $userId — added `use ($userId)`
                return $message->sender_id == $userId
                    ? $message->receiver_id
                    : $message->sender_id;
            })
            ->values(); // Re-index collection after unique()

        return response()->json($conversations);
    }

    // -----------------------------------------------------------------
    // NEW: Delete a message (only the sender can delete their own message)
    // -----------------------------------------------------------------
    public function deleteMessage($messageId)
    {
        $message = Message::where('id', $messageId)
            ->where('sender_id', Auth::id())
            ->firstOrFail();

        $message->delete();

        return response()->json(['message' => 'Message deleted successfully']);
    }

    // -----------------------------------------------------------------
    // NEW: Mark a specific message as read
    // -----------------------------------------------------------------
    public function markAsRead($messageId)
    {
        $message = Message::where('id', $messageId)
            ->where('receiver_id', Auth::id())
            ->firstOrFail();

        $message->update(['is_read' => true]);

        return response()->json(['message' => 'Message marked as read']);
    }

    // -----------------------------------------------------------------
    // NEW: Count unread messages for the authenticated user
    // -----------------------------------------------------------------
    public function unreadCount()
    {
        $count = Message::where('receiver_id', Auth::id())
            ->where('is_read', false)
            ->count();

        return response()->json(['unread_count' => $count]);
    }
}