<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Report;
use App\Models\Category;
use App\Models\Location;
use App\Models\Subscription;   // Fix: were referenced inline with full namespace — imported properly
use App\Models\Booking;        // Fix: same as above
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
        $this->middleware('role:admin');
    }

    // -----------------------------------------------------------------
    // Photographers
    // -----------------------------------------------------------------

    public function getPhotographers(Request $request)
    {
        $photographers = User::where('role', 'photographer')
            ->with('photographerProfile')
            ->when($request->status, function ($query, $status) {
                return $query->where('status', $status);
            })
            ->paginate(20);

        return response()->json($photographers);
    }

    public function updatePhotographerStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:active,suspended,banned'
        ]);

        $photographer = User::findOrFail($id);

        if (!$photographer->isPhotographer()) {
            return response()->json(['error' => 'User is not a photographer'], 400);
        }

        $photographer->update(['status' => $request->status]);

        return response()->json(['message' => 'Photographer status updated successfully']);
    }

    // -----------------------------------------------------------------
    // Reports
    // -----------------------------------------------------------------

    public function getReports(Request $request)
    {
        $reports = Report::with(['client', 'photographer'])
            ->when($request->status, function ($query, $status) {
                return $query->where('status', $status);
            })
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json($reports);
    }

    public function resolveReport($id)
    {
        $report = Report::findOrFail($id);
        $report->update(['status' => 'resolved']);

        return response()->json(['message' => 'Report resolved successfully']);
    }

    public function dismissReport($id)
    {
        $report = Report::findOrFail($id);
        $report->update(['status' => 'dismissed']);

        return response()->json(['message' => 'Report dismissed successfully']);
    }

    // -----------------------------------------------------------------
    // Subscriptions
    // -----------------------------------------------------------------

    public function manageSubscription(Request $request, $id)
    {
        $request->validate([
            'action' => 'required|in:force_delete,reactivate'
        ]);

        $photographer = User::findOrFail($id);

        if (!$photographer->isPhotographer()) {
            return response()->json(['error' => 'User is not a photographer'], 400);
        }

        if ($request->action === 'force_delete') {
            $photographer->photographerProfile()->update([
                'subscription_status'   => 'expired',
                'subscription_end_date' => null,
            ]);

            $photographer->update(['status' => 'suspended']);

            return response()->json(['message' => 'Subscription force deleted successfully']);
        }

        if ($request->action === 'reactivate') {
            $photographer->photographerProfile()->update([
                'subscription_status'   => 'active',
                'subscription_end_date' => now()->addMonth(),
            ]);

            $photographer->update(['status' => 'active']);

            return response()->json(['message' => 'Subscription reactivated successfully']);
        }
    }

    // -----------------------------------------------------------------
    // Locations
    // Fix: duplicate manageLocations() removed — kept the better version
    //      (the second one with $id route param and proper GET handling).
    // Fix: update validation now ignores the current record's own name
    //      using the unique:table,column,except syntax.
    // Fix: Location::create($request->all()) replaced with only() to
    //      avoid mass-assignment of arbitrary fields.
    // -----------------------------------------------------------------

    public function manageLocations(Request $request, $id = null)
    {
        if ($request->isMethod('get')) {
            $locations = Location::all();
            return response()->json($locations);
        }

        if ($request->isMethod('post')) {
            $request->validate([
                'name'   => 'required|string|unique:locations',
                'region' => 'nullable|string',
            ]);

            $location = Location::create($request->only(['name', 'region']));
            return response()->json($location, 201);
        }

        if ($request->isMethod('put') || $request->isMethod('patch')) {
            if (!$id) {
                return response()->json(['error' => 'Location ID is required'], 400);
            }

            $request->validate([
                'name'   => 'sometimes|string|unique:locations,name,' . $id,
                'region' => 'nullable|string',
            ]);

            $location = Location::findOrFail($id);
            $location->update($request->only(['name', 'region']));
            return response()->json($location);
        }

        if ($request->isMethod('delete')) {
            if (!$id) {
                return response()->json(['error' => 'Location ID is required'], 400);
            }

            $location = Location::findOrFail($id);
            $location->delete();
            return response()->json(['message' => 'Location deleted successfully']);
        }

        return response()->json(['error' => 'Method not allowed'], 405);
    }

    // -----------------------------------------------------------------
    // Categories
    // Fix: update and delete used $request->id instead of a route param —
    //      added $id parameter to match how locations are handled.
    // Fix: Category::update($request->all()) replaced with only() to
    //      prevent mass-assignment of slug/name collisions on update.
    // Fix: update validation now ignores the current record's own values.
    // -----------------------------------------------------------------

    public function manageCategories(Request $request, $id = null)
    {
        if ($request->isMethod('get')) {
            $categories = Category::all();
            return response()->json($categories);
        }

        if ($request->isMethod('post')) {
            $request->validate([
                'name'        => 'required|string|unique:categories',
                'slug'        => 'nullable|string|unique:categories',
                'description' => 'nullable|string',
            ]);

            $slug = $request->slug ?: Str::slug($request->name);

            $category = Category::create([
                'name'        => $request->name,
                'slug'        => $slug,
                'description' => $request->description,
            ]);

            return response()->json($category, 201);
        }

        if ($request->isMethod('put') || $request->isMethod('patch')) {
            if (!$id) {
                return response()->json(['error' => 'Category ID is required'], 400);
            }

            $request->validate([
                'name'        => 'sometimes|string|unique:categories,name,' . $id,
                'slug'        => 'sometimes|string|unique:categories,slug,' . $id,
                'description' => 'nullable|string',
            ]);

            $category = Category::findOrFail($id);

            // Regenerate slug if name changed and no explicit slug provided
            if ($request->has('name') && !$request->has('slug')) {
                $request->merge(['slug' => Str::slug($request->name)]);
            }

            $category->update($request->only(['name', 'slug', 'description']));
            return response()->json($category);
        }

        if ($request->isMethod('delete')) {
            if (!$id) {
                return response()->json(['error' => 'Category ID is required'], 400);
            }

            $category = Category::findOrFail($id);
            $category->delete();
            return response()->json(['message' => 'Category deleted successfully']);
        }

        return response()->json(['error' => 'Method not allowed'], 405);
    }

    // -----------------------------------------------------------------
    // Dashboard Stats
    // -----------------------------------------------------------------

    public function getDashboardStats()
    {
        $stats = [
            'total_photographers'  => User::where('role', 'photographer')->count(),
            'active_photographers' => User::where('role', 'photographer')
                ->where('status', 'active')
                ->whereHas('photographerProfile', function ($query) {
                    $query->where('subscription_status', 'active');
                })
                ->count(),
            'total_clients'        => User::where('role', 'client')->count(),
            'pending_reports'      => Report::where('status', 'pending')->count(),
            'total_revenue'        => Subscription::where('status', 'paid')->sum('amount'),
            'monthly_revenue'      => Subscription::where('status', 'paid')
                ->whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)   // Fix: missing year filter — would sum same month across all years
                ->sum('amount'),
            'total_bookings'       => Booking::count(),
            'completed_bookings'   => Booking::where('status', 'completed')->count(),
        ];

        return response()->json($stats);
    }
}