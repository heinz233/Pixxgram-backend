<?php

namespace App\Http\Controllers;

use App\Models\Rating;
use Illuminate\Http\Request;

class RatingController extends Controller
{
    public function store(Request $request, $photographerId)
    {
        $request->validate([
            'stars' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:500'
        ]);

        $rating = Rating::updateOrCreate(
            [
                'client_id' => auth()->id(),
                'photographer_id' => $photographerId
            ],
            [
                'stars' => $request->stars,
                'comment' => $request->comment
            ]
        );

        // Update photographer's average rating
        $this->updatePhotographerRating($photographerId);

        return response()->json(['message' => 'Rating submitted successfully', 'rating' => $rating]);
    }

    private function updatePhotographerRating($photographerId)
    {
        $average = Rating::where('photographer_id', $photographerId)->avg('stars');
        $total = Rating::where('photographer_id', $photographerId)->count();
        
        $photographer = User::find($photographerId);
        $photographer->photographerProfile()->update([
            'average_rating' => round($average, 2),
            'total_ratings' => $total
        ]);
    }
}