<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'photographer_id' => 'required|exists:users,id',
            'booking_date' => 'required|date|after:now',
            'notes' => 'nullable|string'
        ]);

        $booking = Booking::create([
            'client_id' => auth()->id(),
            'photographer_id' => $request->photographer_id,
            'booking_date' => $request->booking_date,
            'notes' => $request->notes,
            'status' => 'pending'
        ]);

        return response()->json(['message' => 'Booking created', 'booking' => $booking]);
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:pending,confirmed,completed,cancelled'
        ]);

        $booking = Booking::findOrFail($id);
        
        // Check if user is either the client or photographer
        if ($booking->client_id != auth()->id() && $booking->photographer_id != auth()->id()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $booking->update(['status' => $request->status]);

        return response()->json(['message' => 'Booking status updated', 'booking' => $booking]);
    }

    public function getBookings()
    {
        $user = auth()->user();
        
        if ($user->isClient()) {
            $bookings = Booking::where('client_id', $user->id)
                ->with('photographer')
                ->orderBy('booking_date', 'desc')
                ->get();
        } else {
            $bookings = Booking::where('photographer_id', $user->id)
                ->with('client')
                ->orderBy('booking_date', 'desc')
                ->get();
        }

        return response()->json($bookings);
    }
}