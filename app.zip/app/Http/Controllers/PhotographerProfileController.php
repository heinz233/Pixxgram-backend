<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Rating;
use App\Models\Portfolio;
use App\Models\Booking;
use App\Models\Report;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class PhotographerController extends Controller
{
    public function index(Request $request)
    {
        $query = User::where('role', 'photographer')
            ->where('status', 'active')
            ->with('photographerProfile');

        // Filter by location
        if ($request->has('location') && $request->location) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('location', 'like', '%' . $request->location . '%');
            });
        }

        // Filter by gender
        if ($request->has('gender') && $request->gender) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('gender', $request->gender);
            });
        }

        // Filter by age range
        if ($request->has('min_age') && $request->min_age) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('age', '>=', $request->min_age);
            });
        }
        
        if ($request->has('max_age') && $request->max_age) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('age', '<=', $request->max_age);
            });
        }

        // Filter by price range
        if ($request->has('min_price') && $request->min_price) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('hourly_rate', '>=', $request->min_price);
            });
        }
        
        if ($request->has('max_price') && $request->max_price) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('hourly_rate', '<=', $request->max_price);
            });
        }

        // Filter by rating
        if ($request->has('min_rating') && $request->min_rating) {
            $query->whereHas('photographerProfile', function ($q) use ($request) {
                $q->where('average_rating', '>=', $request->min_rating);
            });
        }

        // Filter by category
        if ($request->has('category') && $request->category) {
            $query->whereHas('portfolios', function ($q) use ($request) {
                $q->where('category', $request->category);
            });
        }

        $photographers = $query->paginate(20);

        return response()->json($photographers);
    }

    public function show($id)
    {
        $photographer = User::where('role', 'photographer')
            ->with(['photographerProfile', 'portfolios', 'ratingsReceived.client'])
            ->findOrFail($id);

        return response()->json($photographer);
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();
        
        if (!$user->isPhotographer()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }
        
        $profile = $user->photographerProfile;

        $validated = $request->validate([
            'age' => 'sometimes|integer|min:18',
            'gender' => 'sometimes|in:male,female,other',
            'location' => 'sometimes|string|max:255',
            'bio' => 'sometimes|string',
            'hourly_rate' => 'sometimes|numeric|min:0',
            'service_rates' => 'sometimes|array',
            'profile_photo' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        // Handle profile photo upload
        if ($request->hasFile('profile_photo')) {
            $photo = $request->file('profile_photo');
            $filename = time() . '_' . uniqid() . '.' . $photo->getClientOriginalExtension();
            $path = $photo->storeAs('profiles', $filename, 's3');
            $validated['profile_photo'] = Storage::disk('s3')->url($path);
        }

        $profile->update($validated);

        return response()->json(['message' => 'Profile updated successfully', 'profile' => $profile]);
    }

    public function uploadPortfolio(Request $request)
    {
        $request->validate([
            'images' => 'required|array',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'title' => 'required|string',
            'description' => 'nullable|string',
            'category' => 'required|string',
            'tags' => 'nullable|json'
        ]);

        $user = auth()->user();
        
        if (!$user->isPhotographer()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }
        
        if (!$user->photographerProfile->isSubscriptionActive()) {
            return response()->json(['error' => 'Subscription required to upload photos'], 403);
        }

        $tags = $request->tags ? json_decode($request->tags, true) : [];
        $uploadedImages = [];

        foreach ($request->file('images') as $image) {
            $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            
            // Store original image
            $path = $image->storeAs('portfolio', $filename, 'public');
            
            // Create and store thumbnail
            $thumbnail = Image::make($image)->resize(300, 300, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            });
            
            $thumbnailPath = 'thumbnails/' . $filename;
            Storage::disk('public')->put($thumbnailPath, (string) $thumbnail->encode());

            $portfolio = Portfolio::create([
                'photographer_id' => $user->id,
                'title' => $request->title,
                'description' => $request->description,
                'image_url' => Storage::url($path),
                'thumbnail_url' => Storage::url($thumbnailPath),
                'category' => $request->category,
                'tags' => $tags
            ]);

            $uploadedImages[] = $portfolio;
        }

        return response()->json(['message' => 'Portfolio uploaded successfully', 'images' => $uploadedImages]);
    }

    public function getDashboard()
    {
        $user = auth()->user();
        
        if (!$user->isPhotographer()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }
        
        $stats = [
            'subscription_status' => $user->photographerProfile->subscription_status,
            'subscription_end_date' => $user->photographerProfile->subscription_end_date,
            'profile_completion' => $this->calculateProfileCompletion($user),
            'average_rating' => $user->photographerProfile->average_rating,
            'total_ratings' => $user->photographerProfile->total_ratings,
            'reports_summary' => Report::where('photographer_id', $user->id)
                ->where('status', 'pending')
                ->count(),
            'portfolio_analysis' => $this->getPortfolioAnalysis($user),
            'upcoming_bookings' => Booking::where('photographer_id', $user->id)
                ->where('booking_date', '>', now())
                ->where('status', 'confirmed')
                ->count(),
            'total_portfolio_views' => Portfolio::where('photographer_id', $user->id)->sum('views'),
            'total_portfolio_saves' => Portfolio::where('photographer_id', $user->id)->sum('saves'),
            'total_inquiries' => Portfolio::where('photographer_id', $user->id)->sum('inquiries')
        ];

        return response()->json($stats);
    }

    private function calculateProfileCompletion($user)
    {
        $profile = $user->photographerProfile;
        $fields = ['age', 'gender', 'location', 'bio', 'profile_photo', 'hourly_rate'];
        $completed = 0;
        
        foreach ($fields as $field) {
            if (!empty($profile->$field)) {
                $completed++;
            }
        }
        
        return round(($completed / count($fields)) * 100);
    }

    private function getPortfolioAnalysis($user)
    {
        return Portfolio::where('photographer_id', $user->id)
            ->select('id', 'title', 'views', 'saves', 'inquiries')
            ->get();
    }
}
